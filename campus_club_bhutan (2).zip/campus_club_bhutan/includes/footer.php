<footer>
    <div class="footer-container">
        <p>&copy; <?php echo date("Y"); ?> Campus Club & Event Management System | Developed in Bhutan 🇧🇹</p>
        <p>Royal University of Bhutan - Student Project</p>
        <div class="footer-links">
            <a href="/CAMPUS_CLUB_BHUTAN/faq.php">FAQs</a> |
            <a href="/CAMPUS_CLUB_BHUTAN/terms.php">Terms & Conditions</a> |
            <a href="/CAMPUS_CLUB_BHUTAN/privacy.php">Privacy Policy</a>
        </div>
    </div>
</footer>


<!-- Optional JavaScript -->
<script src="/CAMPUS_CLUB_BHUTAN/js/script.js"></script>
</body>
</html>
