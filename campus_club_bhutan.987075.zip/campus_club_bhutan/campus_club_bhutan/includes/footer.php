</main>

<footer>
    <div class="footer-container">
        <p>&copy; <?php echo date("Y"); ?> Campus Club & Event Management System | Developed in Bhutan 🇧🇹</p>
        <p>Royal University of Bhutan - Student Project</p>
    </div>
</footer>

<!-- Optional JavaScript -->
<script src="/js/script.js"></script>
</body>
</html>
